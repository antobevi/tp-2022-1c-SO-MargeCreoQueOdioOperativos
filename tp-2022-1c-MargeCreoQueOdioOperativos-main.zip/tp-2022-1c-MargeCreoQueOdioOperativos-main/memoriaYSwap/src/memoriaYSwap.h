/*
 * memoriaYSwap.h
 *
 *  Created on: 25 abr. 2022
 *      Author: utnso
 */

#ifndef SERVIDOR_MEMORIAYSWAP_H_
#define SERVIDOR_MEMORIAYSWAP_H_
#include "globals.h"
#include "memoria.h"
#include "test.h"
#include "servidor/servidor.h"

#endif /* SERVIDOR_MEMORIAYSWAP_H_ */
